const WHATSAPP = "5491130980881";

// Agregá los perfumes en este arreglo cuando me envíes imágenes y precios.
// "image" puede ser el nombre de un archivo dentro de la carpeta images/.
const products = [
  // Ejemplo:
  // { id: 1, brand: "Afnan", name: "9PM", category: "Hombre", price: 50000, image: "images/afnan-9pm.jpg" }
];

let cart = JSON.parse(localStorage.getItem("essenzaCart") || "[]");

function money(value) {
  return new Intl.NumberFormat("es-AR", {
    style: "currency", currency: "ARS", maximumFractionDigits: 0
  }).format(value);
}

function renderProducts() {
  const container = document.getElementById("products");
  const search = document.getElementById("search").value.toLowerCase().trim();
  const category = document.getElementById("category").value;

  const filtered = products.filter(p =>
    `${p.brand} ${p.name}`.toLowerCase().includes(search) &&
    (category === "all" || p.category === category)
  );

  if (!filtered.length) {
    container.innerHTML = `<div class="empty">El catálogo se está preparando. Pronto vas a encontrar nuestros perfumes acá.</div>`;
    return;
  }

  container.innerHTML = filtered.map(p => `
    <article class="product">
      <div class="product-image">
        ${p.image ? `<img src="${p.image}" alt="${p.brand} ${p.name}">` : `<span>Imagen próximamente</span>`}
      </div>
      <div class="product-info">
        <div class="product-brand">${p.brand}</div>
        <h3>${p.name}</h3>
        <div class="product-category">${p.category}</div>
        <div class="price">${money(p.price)}</div>
        <button class="add-button" onclick="addToCart(${p.id})">Agregar al pedido</button>
      </div>
    </article>
  `).join("");
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  if (!product) return;
  const item = cart.find(i => i.id === id);
  if (item) item.qty++;
  else cart.push({ id, qty: 1 });
  saveCart();
  openCart();
}

function changeQty(id, delta) {
  const item = cart.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(i => i.id !== id);
  saveCart();
  renderCart();
}

function saveCart() {
  localStorage.setItem("essenzaCart", JSON.stringify(cart));
  renderCart();
}

function renderCart() {
  const container = document.getElementById("cartItems");
  let total = 0;
  let count = 0;

  if (!cart.length) {
    container.innerHTML = `<p style="color:#a7a39a;padding:20px 0">Todavía no agregaste perfumes.</p>`;
  } else {
    container.innerHTML = cart.map(item => {
      const p = products.find(x => x.id === item.id);
      if (!p) return "";
      total += p.price * item.qty;
      count += item.qty;
      return `
        <div class="cart-row">
          <div class="cart-row-info">
            <strong>${p.brand} ${p.name}</strong><br>
            <small>${money(p.price)} c/u</small>
          </div>
          <div class="qty">
            <button onclick="changeQty(${p.id},-1)">−</button>
            <span>${item.qty}</span>
            <button onclick="changeQty(${p.id},1)">+</button>
          </div>
        </div>`;
    }).join("");
  }

  document.getElementById("cartTotal").textContent = money(total);
  document.getElementById("cartCount").textContent = count;
}

function toggleCart() {
  document.getElementById("cartOverlay").classList.toggle("hidden");
  renderCart();
}

function openCart() {
  document.getElementById("cartOverlay").classList.remove("hidden");
  renderCart();
}

function closeCartOutside(event) {
  if (event.target.id === "cartOverlay") toggleCart();
}

function sendOrder(event) {
  event.preventDefault();
  if (!cart.length) {
    alert("Agregá al menos un perfume al pedido.");
    return;
  }

  const name = document.getElementById("customerName").value.trim();
  const address = document.getElementById("customerAddress").value.trim() || "No indicada";
  const payment = document.getElementById("payment").value;

  let total = 0;
  let lines = cart.map(item => {
    const p = products.find(x => x.id === item.id);
    const subtotal = p.price * item.qty;
    total += subtotal;
    return `• ${p.brand} ${p.name} x${item.qty} — ${money(subtotal)}`;
  });

  const message =
`🖤 *NUEVO PEDIDO — ESSENZA LUXUR*

👤 Cliente: ${name}

${lines.join("\n")}

💰 *TOTAL: ${money(total)}*

📍 Dirección: ${address}
💳 Medio de pago: ${payment}`;

  window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`, "_blank");
}

renderProducts();
renderCart();
